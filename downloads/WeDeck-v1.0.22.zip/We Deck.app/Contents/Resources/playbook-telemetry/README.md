# PlayBook Skill 统计

支持 Claude Code、Codex、Grok、AGY。仅记录 catalog 中的 Skill 激活事件，继续使用现有队列、去重、历史记录与 ClickHouse 上报字段。

新增宿主的配置位置：

| Agent | 配置 | 采集入口 |
| --- | --- | --- |
| AGY | `~/.gemini/config/hooks.json` 中的 `weagent-playbook-telemetry` | `PostToolUse` |

We Deck 启动时只检测本地运行时、Skill 目录和宿主 Hook，不会安装 Hook、修改配置或发送诊断事件。新用户默认未配置。需要启用、升级或修复时，在「PlayBook 统计」点击「配置统计」/「修复配置」并确认。修复会保留已有客户端标识和有效的上报地址；如果宿主禁止 Hook 或配置文件不可解析，请按状态提示先在宿主侧处理。

接口依据：

- [AGY Hooks](https://antigravity.google/docs/hooks)

AGY 在工具执行成功后采集，失败调用不计入；统计 Hook 不参与权限决策。

1.0.14 移除 Pi / OMP 适配。升级时仅将本应用生成的旧统计扩展重命名为不可加载的备份；保留用户配置与其他扩展。旧宿主的队列事件不再上报。
