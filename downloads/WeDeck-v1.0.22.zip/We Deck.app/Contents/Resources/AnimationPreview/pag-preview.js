"use strict";

const canvas = document.getElementById("preview");
const send = (kind, value) => webkit.messageHandlers.pagPreview.postMessage(JSON.stringify({kind, value}));
const bytes = (base64) => Uint8Array.from(atob(base64), (character) => character.charCodeAt(0));
let PAG, file, player;
let playing = false;
let progress = 0;
let lastRender = 0;
let lastNotice = 0;
let requests = Promise.resolve();
let seekPending = false;
let tickID = 0;
let monitored = false;
let fillsStage = false;
let sampleStart = 0;
let sampleCount = 0;
let sampleMilliseconds = 0;
let resizePending = false;

const report = (error) => send("error", String(error && error.message || error));
const serialize = (operation) => { requests = requests.then(operation).catch(report); };

async function initialize(pag, decoder, animation, fill) {
    PAG = await libpag.PAGInit({wasmBinary: bytes(pag)});
    const FFAVC = await ffavc.FFAVCInit({wasmBinary: bytes(decoder)});
    PAG.registerSoftwareDecoderFactory(new FFAVC.FFAVCDecoderFactory());
    file = await PAG.PAGFile.load(bytes(animation).buffer);
    const width = file.width(), height = file.height();
    const duration = file.duration() / 1e6, fps = file.frameRate();
    if (!(width > 0 && height > 0 && width <= 8192 && height <= 8192 && duration > 0 && fps > 0 && fps <= 240)) {
        throw Error("不支持此 TCMP4 的画布、时长或帧率。");
    }
    fillsStage = fill;
    resizeCanvas();
    player = await PAG.PAGView.init(file, canvas, {useCanvas2D: true, useScale: false, firstFrame: false});
    player.setScaleMode(fillsStage ? 3 : 2); // PAGScaleMode.Zoom / LetterBox
    await draw();
    const slots = [
        ...editableIndices(3).map(i => ({id:`text:${i}`, name:`文字 ${i}`, kind:"text"})),
        ...editableIndices(5).map(i => ({id:`image:${i}`, name:`图片 ${i}`, kind:"image"}))
    ];
    const {layers, layersTruncated} = inspectLayers();
    send("ready", {width, height, duration, fps, slots, layers, layersTruncated});
    new ResizeObserver(scheduleResize).observe(canvas);
}

function resizeCanvas() {
    const ratio = Math.min(devicePixelRatio, 2048 / Math.max(1, canvas.clientWidth, canvas.clientHeight));
    const width = Math.max(1, Math.round(canvas.clientWidth * ratio));
    const height = Math.max(1, Math.round(canvas.clientHeight * ratio));
    if (canvas.width === width && canvas.height === height) return false;
    canvas.width = width;
    canvas.height = height;
    return true;
}

function scheduleResize() {
    if (resizePending) return;
    resizePending = true;
    serialize(async () => {
        resizePending = false;
        if (resizeCanvas()) player.updateSize();
        player.setScaleMode(fillsStage ? 3 : 2);
        await draw();
    });
}

function inspectLayers() {
    const layers = [];
    const names = ["未知", "空对象", "纯色", "文字", "形状", "图片", "预合成"];
    // shortcut: bound the layer list sent to Swift; use paged inspection if larger files need the full tree.
    let layersTruncated = false;
    function visit(composition, depth, parent) {
        const count = composition.numChildren();
        for (let i = 0; i < count; i++) {
            if (layers.length >= 500 || depth >= 12) { layersTruncated = true; return; }
            const id = `${parent}/${i}`;
            const layer = composition.getLayerAt(i);
            try {
                const type = layer.layerType();
                layers.push({id, depth, name: layer.layerName() || `图层 ${i + 1}`, kind: names[type] || names[0]});
                if (type === 6 && typeof layer.numChildren === "function") visit(layer, depth + 1, id);
            } finally { layer.destroy(); }
        }
    }
    // Metadata inspection must not prevent previewing otherwise readable files.
    try { visit(file, 0, ""); } catch { layersTruncated = true; }
    return {layers, layersTruncated};
}

function editableIndices(type) {
    const result = file.getEditableIndices(type);
    if (Array.isArray(result)) return [...new Set(result)];
    // Older Emscripten bindings expose a vector rather than a JavaScript array.
    try { return [...new Set(Array.from({length: result.size()}, (_, i) => result.get(i)))]; }
    finally { result.delete?.(); }
}

async function draw() {
    if (player) {
        player.setProgress(Math.min(0.999999, Math.max(0, progress)));
        await player.flush();
    }
}

async function drawLatest() {
    let rendered;
    do { rendered = progress; await draw(); } while (rendered !== progress);
}

function tick(now) {
    tickID = 0;
    if (!playing) return;
    const interval = 1000 / file.frameRate();
    if (!seekPending && now - lastRender >= interval - 2) {
        progress = (progress + (now - lastRender) / (file.duration() / 1000)) % 1;
        lastRender = now;
        seekPending = true;
        serialize(async () => {
            try {
                const start = performance.now();
                await drawLatest();
                if (monitored && playing) {
                    if (!sampleStart) sampleStart = start;
                    sampleCount++;
                    sampleMilliseconds += performance.now() - start;
                    if (now - sampleStart >= 1000) {
                        send("metrics", {fps: sampleCount * 1000 / (now - sampleStart),
                                         averageMilliseconds: sampleMilliseconds / sampleCount});
                        sampleStart = now;
                        sampleCount = sampleMilliseconds = 0;
                    }
                    if (now - lastNotice >= 100) { lastNotice = now; send("progress", progress); }
                }
            } finally { seekPending = false; }
        });
    }
    tickID = requestAnimationFrame(tick);
}

window.preview = {
    initialize,
    fill(value) {
        if (value !== fillsStage) { fillsStage = value; scheduleResize(); }
    },
    monitor(value) {
        monitored = value;
        sampleStart = sampleCount = sampleMilliseconds = 0;
        if (value) send("progress", progress);
    },
    play(value) {
        playing = value;
        lastRender = performance.now();
        sampleStart = sampleCount = sampleMilliseconds = 0;
        if (value && !tickID) tickID = requestAnimationFrame(tick);
        if (!value) {
            cancelAnimationFrame(tickID);
            tickID = 0;
            send("progress", progress);
        }
    },
    seek(value) {
        progress = value;
        lastRender = performance.now();
        if (!seekPending) {
            seekPending = true;
            serialize(async () => {
                try {
                    await drawLatest();
                } finally { seekPending = false; }
            });
        }
    },
    replaceText(id, text) {
        serialize(async () => {
            const index = Number(id.split(":")[1]);
            const data = text === null ? null : file.getTextData(index);
            if (data) data.text = text;
            try { file.replaceText(index, data); await draw(); }
            finally { data?.delete?.(); }
        });
    },
    replaceImage(id, base64) {
        serialize(async () => {
            const index = Number(id.split(":")[1]);
            const url = base64 === null ? null : URL.createObjectURL(new Blob([bytes(base64)], {type:"image/png"}));
            let image;
            try {
                if (url) {
                    const element = new Image();
                    element.src = url;
                    await element.decode();
                    image = PAG.PAGImage.fromSource(element);
                }
                file.replaceImage(index, image ?? null);
                await draw();
            } finally {
                image?.destroy();
                if (url) URL.revokeObjectURL(url);
            }
        });
    }
};
