# Offline PAG runtime

Unmodified web distributions used to read unencrypted TCMP4/PAG in WKWebView.
Neither preview files nor slot replacements are sent over the network.

- libpag 4.1.8 (Apache-2.0 and bundled component terms):
  https://registry.npmjs.org/libpag/-/libpag-4.1.8.tgz
  (contains the JavaScript/TypeScript sources and copyright notices).
- ffavc 1.0.2 (LGPL-2.1): https://registry.npmjs.org/ffavc/-/ffavc-1.0.2.tgz
  Corresponding complete source (including the FFmpeg snapshot, bindings, and
  `scripts/build_ffmpeg_web.sh`):
  https://github.com/libpag/ffavc/tree/2b1d780401db1fca6ca2342858269b71efe2c801
  The decoder is loaded separately at runtime. To use a compatible modified decoder in a
  local build, replace `ffavc.min.js` and `ffavc.wasm` in this directory before packaging.
  You may modify the decoder and reverse engineer the application as needed to debug those modifications.

These runtimes do not implement Tencent's enterprise authorization or protected asset playback.
