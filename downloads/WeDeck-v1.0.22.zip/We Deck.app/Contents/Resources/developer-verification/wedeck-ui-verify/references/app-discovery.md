# 内置 App 与源码发现

下表来自各仓库 `app/build.gradle` 与 `gradle.properties`。App 的 id 即 `prepare --app` 的取值，源码在 `~/wenext-limited/<仓库>`。包名以设备上 `pm path` 实际结果为准；渠道包（huawei、lite）包名带后缀，需在 App 配置里改包名后再运行。

| id | 仓库 | 包名 | 深链 scheme://host | 其他渠道 |
| --- | --- | --- | --- | --- |
| lama | lama-android | com.wenext.lama | wenext://lama | huawei、lite（lite 包名 com.wenext.voice） |
| yoki | yoki-android | com.partyjoy.yoki | partyki://yoki | huawei、lite（.lite 后缀） |
| waka | wyak-android | com.wenext.wayak | wenext://wayak | lite（com.wenext.wyaklite） |
| fungo | fungo-android | com.gamparty.fungo | gamparty://fungo | huawei（.huawei 后缀） |
| inchat | gameparty-android | com.wenext.inchat | partychat://inchat | 无 |
| gameparty-pro | gameparty-pro-android | com.partyjoy.gameparty.pro.hw | gmparty://gameparty | 无 |
| hayi | hayi-android | com.gamparty.hayi | haparty://hayi | huawei（.huawei 后缀） |
| hichat | hichat-android | com.partyjoy.hichat | partyhi://hichat | 无 |
| ludo | ludo-android | com.courage.ludo | courage://ludo | huawei（.huawei 后缀） |
| ludoksa | ludoksa-android | com.courage.ludo.ksa.hw | courageksa://ludo | 无 |
| weparty | weparty-android | com.partyjoy.weparty | partyjoy://weparty | 无 |

仅在当前设备 UI 或已选经验不足以确定入口时查询这些源码约定：

- 11 个项目都基于 wenext-android-frame，页面由 `@RouterUri(path=[...])` 注册，深链形如 `scheme://host/path?参数`；先在仓库里 `rg "RouterUri"` 找到真实 path 和参数，再用 `openLink` 或 `adb shell am start -a android.intent.action.VIEW -d '...'` 直达。
- 主界面都是 `com.adealink.weparty.MainActivity`；启动用本工具的 `launch`/`launch_app`，不要自己写 `launchApp`。
- 全部带 `/debug` 页面（`DebugActivity`），`?testAccount=正整数` 可切换测试账号；仅 Debug 构建可用，生产环境不得使用。优先复用已有登录态。需要重新登录时，只用开发者明确提供的测试方式或账号；缺少前置就报告 blocked。
- Debug 构建带 LeakCanary，会多出一个启动图标，本工具的 `launch` 已排除。
- 视图为 XML + ViewBinding：控件 id 通常是 `binding` 对应的 `@+id/...`，先用当前 UI 树取得 resource id；只有节点缺失或语义不明时才定向查看对应 Activity/Fragment 的布局，并回到设备核对。
- 未装对应渠道包时，preflight 会直接提示包名不匹配，按提示修改 App 配置，不要反复重试。
