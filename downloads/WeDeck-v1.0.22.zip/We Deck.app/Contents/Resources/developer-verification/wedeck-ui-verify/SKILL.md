---
name: wedeck-ui-verify
description: 面向客户端开发者，使用 We Deck 在已连接 Android 设备上验收需求、复现问题、巡检发版界面或回放 YAML；批量执行已知导航，保存截图、报告和可复用流程。
---

# 自动化UI · 执行协议 v4

直接使用当前开发会话的需求与验收点，保留已有登录态。We Deck 调度时 App、设备、目录已绑定，使用 `wedeck_ui` MCP；不重复发现 App、设备或扫描全局记忆。当前会话读过本版 Skill / 协议后不重复读；续接优先利用上下文，只补缺失信息。

## 先规划路径，再批量执行

1. `session_start` 连接设备；首次执行用 `launch_app` 启动，再 `look` 一次。续接先 `look` 核对当前页，已在目标 App 时接着当前位置。
2. 依据本轮目标、已选经验和这次观察，列一份简短路径计划：**目标 → 父页面标志 → 入口选择器 → 等待/结果标志 → 截图 → 返回方式**。只在缺少信息的边界停下来观察。
3. **一次观察，收集当前父页面所有相关入口**。稳定 resource id、文本/语义、必要的父容器和已核对顺序的 index 留在当前会话的页面笔记中；标明哪些只是可见入口、哪些路线已经走通。返回该父页后用一个页面标志核对，直接使用记下的其他入口，不重复 `look`、读源码或寻找同一个 viewId。相同 id 多次出现时加容器/文本/已确认的 index，不能只记一个有歧义的 id。
4. **把可预测的最长连续路径合并成一次 `run`**：切页、等待、断言、命名截图、返回再进入下一分支可以在同一 YAML 列表完成。已知五个 Tab 的入口和顺序时，一批依次切换并截图；不要求每个 Tab 单独模型判断。入口同在父页的多个目标，按“父页 → A → 返回父页 → B”组织；尚未知道目标页返回方式时，首次走到该页观察一次，然后接着执行剩余路径。
5. 等待由引擎的元素等待/页面稳定和 `extendedWaitUntil` 等条件完成，断言留在 YAML 内执行，**不等于每次断言都要让模型再读屏**。有业务加载标志时等待真实标志；不加固定 sleep 或无意义的重复断言。未知下一层入口、阻塞弹窗、失败或必须判断动态业务状态时再 `look`；确有缺失节点才 `look(all=true)`。
6. 视觉任务在批次内 `takeScreenshot: captures/01-页面名`，同批每个检查点用不同名字，参数不带 `.png`。执行器创建 captures 目录，将新截图归档到唯一的 screenshots 文件，MCP 一次返回这批图片和证据路径。**批量操作完成后统一审阅图片，再下结论**；无需为了看图重走页面。预览宽度 500px，细节不足时按返回路径读取原图。操作成功不等于视觉通过。
7. 批次失败会停止后续步骤，已完成截图仍返回并归档。根据返回的页面差异和失败位置处理，必要时观察一次，只修复失败段及剩余项；不重跑成功部分，不循环提交业务动作。同一问题局部重试最多两次，仍失败保留现场并写 failed / blocked。

导航笔记在会话内复用；长流程或有续接价值时可写到本轮 `navigation.md`，只记页面标志、稳定入口、已验证到达/返回路径及待探索处。不同 App、弹窗、账号、构建或页面结构变更时重新核对受影响的部分。`@ref` 只用于当前观察，不能跨页、跨轮次或写进经验。坐标和猜测不能充当稳定路线。

## 复用与学习

- 只使用本轮显式选入的经验 / YAML。提示已给出完整复用说明时直接判断适用条件；缺少内容才 `knowledge`，选择为空时跳过。相关链路核对起点后 `apply_knowledge(id)`，不重新探索或重写现有 YAML；版本号不同本身不是放弃复用的理由。
- 新发现的稳定路径由 AI 自动积累，不要求开发者提供 YAML 或步骤编号。完成后 `save_flow` 获取真实成功步骤编号，在 `finish.learnings` 提交片段、提示和起终点；执行器截取原 YAML 入库。按独立导航能力保存，例如“父页到 A”，不要只存包含五个目标的整场巡检。
- 复用提示写清：适用页面/账号/环境、父页标志、已验证入口选择器、目标页标志，以及实际验证过的返回方式。可见但未点击的入口只作本轮候选，不宣称路线已验证；只适合说明的内容存 `kind: rule`。
- 不为学习 clear 或重跑。没有可靠片段时 `learnings: []` 并说明原因；不保存密码、验证码、Token、临时坐标或失败猜测。首次提交学习格式或需要更多例子时，按需读[执行与学习协议](references/execution-protocol.md)。

## YAML 与结果

`run.commands` 传单条命令或 YAML 列表，不含 `appId` / `---` 头部；回放文件由执行器保存头部。初始启动使用 `launch_app`，不要在流程里再写 `launchApp`。

常用命令：`tapOn`、`inputText`、`pressKey`、`hideKeyboard`、`scrollUntilVisible`、`extendedWaitUntil`、`assertVisible`、`assertNotVisible`、`takeScreenshot`、`runFlow`。引擎 Speedrun 0.4.4；不支持 `assertWithAI`。跨页使用实际确认过的稳定选择器，优先 resource id，其次文本；多语言差异写入前置。

- 原报告、截图、YAML、AI 输出留在各自 `rounds/轮次-id/`，不移动或覆盖。本轮文件只写返回的产物目录，证据引用执行器返回的 `rounds/…/screenshots/…` 归档路径；`captures/` 是引擎工作输出，不作为持久证据路径。
- 续接只推进补充目标和未完成项。上下文足够时不重读旧报告/协议；不清楚上轮做到哪里时，按返回的路径定向读上一轮 `run.json` / `navigation.md`，不要全量读历史日志、图片和报告。历史清单由执行器保留，未变化项不重提；受变化影响的项才重验，并沿用原检查项 id。
- 收尾 `save_flow`，审阅本批截图和断言结果后 `finish`。**同一会话一份清单，checks 只提交本次新增或有变化的项**：每项包含稳定语义 `id`、title、status（passed / failed / blocked）、evidence（实际结果和归档路径）。id 小写字母开头，可含数字、点、横线、下划线，最多 80 字符；复验/改名用原 id，新目标用新 id。执行器合并并保留未提交的旧项及未解决失败，勿逐项重复“沿用历史”。新要求中未观察、前置缺失或仅点击成功的项目仍须新增 blocked 项。无变化可传 checks: []；summary 简述当前结论。
- `finish` 自动归档报告、学习结果，停止设备会话并恢复动画。中文总结真实结果和实际入库内容。异常中断时 `session_stop`，保留已产生的证据。
- 源码只读、按需查询；当前 UI 能确定入口时不查源码。不要运行 Git / Gradle / 单元测试，不构建/安装、不清数据或切网络环境。目标之外的发消息、上麦、购买、支付、删除、改资料不执行；测试登录只用用户明确允许的方式。

## 开发者自己的 Agent / CLI

从本 Skill 目录定位 `scripts/wedeck-ui`；先 `apps`、`devices` 取实际配置和明确 serial，再 prepare。这个脚本调用已安装的独立执行器，不要求桌面窗口保持打开。需要项目/渠道/深链发现时才读[内置 App 约定](references/app-discovery.md)，绑定的 We Deck 会话通常不需要。

```sh
"$SKILL_DIR/scripts/wedeck-ui" apps
"$SKILL_DIR/scripts/wedeck-ui" devices
"$SKILL_DIR/scripts/wedeck-ui" prepare --app APP_ID --device SERIAL --mode visual --intent '需求与验收点'
"$SKILL_DIR/scripts/wedeck-ui" start --run RUN_DIR
"$SKILL_DIR/scripts/wedeck-ui" launch --run RUN_DIR
"$SKILL_DIR/scripts/wedeck-ui" look --run RUN_DIR
"$SKILL_DIR/scripts/wedeck-ui" do --run RUN_DIR --commands 'YAML列表'
"$SKILL_DIR/scripts/wedeck-ui" save --run RUN_DIR
"$SKILL_DIR/scripts/wedeck-ui" finish --run RUN_DIR --report REPORT.json
```

CLI 返回同一批截图文件路径，由 Agent 的图片工具集中读取。普通 start/replay 不重复执行已结束记录；We Deck 发起的 AI 会话用 `resume --run RUN_DIR --prompt '补充提示'` 续接原 Codex 会话，不重新 prepare。每个命令显式传 `--run`。其他用法通过 `--help` 查看；支持 MCP 的客户端可以注册脚本的 `mcp` 命令。

`knowledge` 列出经验与流程，prepare 的 `--context 'knowledge:ID,flow:ID'` 显式选入；`knowledge --run RUN_DIR` 查看快照；`apply-knowledge --run RUN_DIR --id ID` 直接复用。分享时从运行记录的流程菜单保存到库，导出整个流程目录；外部 YAML 可导入流程库，导入不执行也不新增运行记录。脚本、图片和子流程用相对路径放入 `flow-package/`；不要包含账号密钥或无关个人数据。
