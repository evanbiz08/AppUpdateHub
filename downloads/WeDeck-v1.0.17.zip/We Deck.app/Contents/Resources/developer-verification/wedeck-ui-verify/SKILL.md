---
name: wedeck-ui-verify
description: "面向客户端开发者，在需求完成后操作已连接 Android 设备验证界面、复现问题、巡检发版展示或回放固定流程。通过 We Deck 的执行器观察真实 UI、断言结果、保存截图与 YAML；支持 Lama、Yoki、Waka 及用户配置的 App。"
---

# 自动化UI

使用当前开发会话已有的需求、改动与验收点，补充必要的运行前置。不要把开发者任务改写成独立测试工程，也不要生成单元测试或擅自构建、安装、清空 App。

## 选择入口

We Deck 调度的会话已绑定 App、设备和运行目录，直接使用 `wedeck_ui` MCP。

在开发者自己的 Agent 中，从本 SKILL.md 所在目录定位 `scripts/wedeck-ui`，先执行 `apps`、`devices` 获取实际配置和明确的设备 serial。这个脚本调用已安装 We Deck 中的独立执行器，不要求桌面窗口保持打开。

```sh
"$SKILL_DIR/scripts/wedeck-ui" apps
"$SKILL_DIR/scripts/wedeck-ui" devices
"$SKILL_DIR/scripts/wedeck-ui" prepare --app APP_ID --device SERIAL --mode feature --intent '本次需求与验收点'
```

prepare 返回 `run` 目录；之后每个命令显式传递该目录：

```sh
"$SKILL_DIR/scripts/wedeck-ui" start --run RUN_DIR
"$SKILL_DIR/scripts/wedeck-ui" launch --run RUN_DIR
"$SKILL_DIR/scripts/wedeck-ui" look --run RUN_DIR --screenshot
"$SKILL_DIR/scripts/wedeck-ui" look --run RUN_DIR
```

其他命令：`do --commands 'YAML'`、`look --all`、`save`、`clear --starting-state '实际起点'`、`log`、`stop`、`finish --report FILE.json`，均需要 `--run RUN_DIR`。支持 MCP 的客户端也可以注册本脚本的 `mcp` 命令；它提供同一套执行和归档能力。

## 执行时的关键判断

- `start`/`session_start` 只连接设备，不保证目标 App 在前台。CLI 使用 `launch`，MCP 使用 `launch_app`，随后观察并核对包名/目标页面。该入口会处理 Debug 构建额外的 LeakCanary 图标，避免 Speedrun 0.4.4 将系统选择器误判为主入口。不要使用 clearState 作为默认启动参数。
- 按真实 UI 的 resource id、文本或当前 @引用操作。@引用不能凭空猜测；操作后重新观察。看不到节点时使用完整树或截图，不用坐标猜测跨 App 通用流程。
- 页面内功能的验证可以在查明真实 Router/DeepLink 后直达；入口路径本身属于验收点时必须走真实路径。仅 Activity resumed、点击成功或控件存在不能替代业务结果断言。
- 已有登录态优先复用。未登录且用户提供了明确的测试环境账号时，可使用项目已有 Debug 登录能力；先确认实际项目契约。生产环境不使用测试账号绕过登录。前置缺失用 blocked，不能编造账号、房间号或登录成功。
- 只执行用户目标内的业务行为，不擅自发送消息、赠礼、购买、支付、删除或修改资料。相同失败最多诊断重试两次，避免重复提交业务数据。
- 项目源码用于只读发现控件和入口，遵守该项目 AGENTS.md。不要因为验收失败就顺带改源码、切环境、执行 Git 或 Gradle；这需要另一个明确的开发任务。

## 根据目标调整验证

- 需求验收：逐条验证改动后的可见行为，覆盖相关状态和边界；需求没覆盖或前置不满足的项明确标出。
- 问题复现：记录触发条件、所有失败尝试、实际状态和截图。不要将“未复现”写成问题已修复。
- 发版巡检：按指定固定操作逐项验证，保存稳定的 YAML，复用公共流程时保留 App 专属选择器和环境差异。
- 视觉检查：获取截图，按参考图或验收标准检查布局、文案、遮挡、截断、语言及状态。没有参考图时不声称像素一致。动态动画需要观察多个时刻，静态截图不能证明完整动画或音视频正常。
- 固定流程回放：prepare 时选择 replay，然后执行 `replay --run RUN_DIR --flow FILE_OR_DIRECTORY`。执行器先启动所选 App，再回放 YAML；初始启动不用写进 YAML。无需模型全程操作；相对资源由原流程目录解析。执行前核对 YAML 的 appId、环境、账号前置和数据修改行为与当前目标一致。导入的 YAML 若自己包含 launchApp，仍受上游多启动入口解析限制，需要按实际目标调整。

## 保存结果

执行中按需 `look --screenshot`；截图路径在返回文本中，可由 Agent 的图片工具查看。完整尝试保存在 `operations.jsonl`。`save`/`save_flow` 仅保存成功操作为 `flow.yaml`，不包含失败尝试，不能单独作为问题复现报告。

达到稳定的验证起点后，用 CLI `clear --starting-state` 或 MCP `session_clear` 开始录制可回放部分。起点和前置写入 flow-context.json，流程开头增加起点断言。偶然弹出的系统窗口、手动登录等 setup 不要混进固定操作；完整尝试日志不受清理录制影响。

结束前保存有效流程，然后提交每个验收点的结论。CLI 将下面的结构写成运行目录内 JSON，再调用 `finish --run RUN_DIR --report FILE.json`；MCP 使用 `finish` 工具。

```json
{
  "summary": "实际观察到的结果与未验证范围",
  "checks": [
    {"title": "用户要求的验收点", "status": "passed", "evidence": "具体观察、断言、截图路径或业务状态"},
    {"title": "缺少前置的验收点", "status": "blocked", "evidence": "缺少什么，已经验证到哪一步"}
  ]
}
```

status 只使用 passed、failed、blocked。所有要求都应有结论；只有点击成功、进程退出码为 0 或部分步骤完成时不能整体通过。UI 证据不替代未检查的后端或双账号业务结果。

finish 会停止设备会话、恢复动画设置并释放占用。异常中断时执行 stop，保留已产生的证据。每次 prepare/session_start 创建新的本地运行记录，桌面「自动化UI → 运行记录」自动显示，可单独删除已结束记录。

要复用或分享，在运行记录的「流程」菜单中保存到流程库，再导出或分享 YAML。也可以在流程库导入别人发来的 YAML，选择对应 App 和设备后运行；导入不会自动执行，也不会新增运行记录。包含相对路径子流程、脚本或图片时，导入和分享整个流程目录。流程库与运行记录分别保存，删除运行记录不会删除已入库的流程。不把账号密钥或无关个人信息复制到报告或共享 YAML。
