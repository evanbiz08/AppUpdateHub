#!/usr/bin/env python3
"""Manifest-scoped PNG -> CrispPNG -> lossless WebP. Python 3.9+, no pip dependencies."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import zlib


def run(args):
    result = subprocess.run(args, capture_output=True, text=True, timeout=180)
    if result.returncode:
        message = (result.stderr or result.stdout)[-2000:]
        try:
            errors = json.loads(result.stdout).get('errors', [])
            if errors: message = '; '.join(str(e.get('code')) + ': ' + str(e.get('message')) for e in errors)
        except (ValueError, AttributeError): pass
        raise RuntimeError(f'{Path(args[0]).name} exit={result.returncode}: {message}')
    return result.stdout


def png_rgba(path):
    """Decode non-interlaced PNG to RGBA8, retaining transparent RGB for exact comparison."""
    raw = path.read_bytes()
    if raw[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('not PNG')
    pos, payload, palette, alpha = 8, b'', b'', b''
    while pos < len(raw):
        size = struct.unpack('>I', raw[pos:pos + 4])[0]
        tag = raw[pos + 4:pos + 8]
        data = raw[pos + 8:pos + 8 + size]
        if tag == b'IHDR':
            width, height, depth, color, compression, filtering, interlace = struct.unpack('>IIBBBBB', data)
            if interlace or compression or filtering or depth == 16:
                raise ValueError('interlaced/16-bit PNG requires explicit normalization before lossless RGBA8 conversion')
            if width * height > 40_000_000:
                raise ValueError('image exceeds 40 million pixels')
        elif tag == b'PLTE': palette = data
        elif tag == b'tRNS': alpha = data
        elif tag == b'IDAT': payload += data
        elif tag == b'IEND': break
        pos += size + 12
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}[color]
    stride = (width * channels * depth + 7) // 8
    bpp = max(1, (channels * depth + 7) // 8)
    decoded = zlib.decompress(payload)
    if len(decoded) != height * (stride + 1): raise ValueError('invalid PNG scanlines')
    previous, pixels = bytearray(stride), bytearray()
    for y in range(height):
        offset = y * (stride + 1)
        method = decoded[offset]
        row = bytearray(decoded[offset + 1:offset + 1 + stride])
        for x in range(stride):
            a, b, c = (row[x-bpp] if x >= bpp else 0), previous[x], (previous[x-bpp] if x >= bpp else 0)
            if method == 1: row[x] = (row[x] + a) & 255
            elif method == 2: row[x] = (row[x] + b) & 255
            elif method == 3: row[x] = (row[x] + (a+b)//2) & 255
            elif method == 4:
                p = a+b-c
                distances = [abs(p-a), abs(p-b), abs(p-c)]
                row[x] = (row[x] + [a,b,c][distances.index(min(distances))]) & 255
            elif method != 0: raise ValueError('unknown PNG filter')
        samples = list(row) if depth == 8 else [(row[i*depth//8] >> (8-depth-i*depth%8)) & ((1<<depth)-1) for i in range(width*channels)]
        for x in range(width):
            v = samples[x*channels:(x+1)*channels]
            if color == 6: rgba = v
            elif color == 2: rgba = v + [0 if len(alpha) == 6 and tuple(v) == struct.unpack('>HHH', alpha) else 255]
            elif color == 3:
                rgba = list(palette[v[0]*3:v[0]*3+3]) + [alpha[v[0]] if v[0] < len(alpha) else 255]
                if len(rgba) != 4: raise ValueError('invalid palette index')
            elif color == 4: rgba = [v[0]]*3 + [v[1]]
            else:
                gray = v[0]*255//((1<<depth)-1)
                rgba = [gray]*3 + [0 if len(alpha) == 2 and v[0] == struct.unpack('>H', alpha)[0] else 255]
            pixels.extend(rgba)
        previous = row
    return width, height, bytes(pixels)


def process(args):
    manifest = Path(args.manifest).resolve(strict=True)
    source = Path(args.input_dir).resolve(strict=True)
    destination = Path(args.out_dir).resolve(strict=True)
    if not destination.name.startswith('drawable') or destination.parent.name != 'res':
        raise ValueError('out-dir must be an existing Android res/drawable* directory')
    entries = json.loads(manifest.read_text())
    if not isinstance(entries, list): raise ValueError('manifest must be an array')
    for tool in ['crisppng', 'cwebp', 'dwebp']:
        if not shutil.which(tool): raise ValueError(f'missing CLI: {tool}')
    phase = args.phase0 or os.environ.get('CRISPPNG_PHASE0')
    if not phase:
        packaged = Path('/Applications/CrispPNG.app/Contents/Resources/config/phase0.toml')
        if packaged.is_file(): phase = str(packaged)
    if phase: phase = str(Path(phase).resolve(strict=True))
    if args.compression_mode == 'production':
        if not phase: raise ValueError('production compression requires --phase0 or CRISPPNG_PHASE0')
        run(['crisppng', 'doctor', '--production', '--phase0', phase, '--json'])
        compression_options = ['--phase0', phase]
    else:
        compression_options = ['--local']
        if phase:
            # The CLI itself checks the configured Imagequant license before allowing local palette candidates.
            compression_options += ['--local-palette', '--phase0', phase]
    report = {'schemaVersion': 1, 'status': 'SUCCESS', 'compressionMode': args.compression_mode, 'assets': [], 'failedAssets': []}
    names = set()
    for entry in entries:
        name = entry.get('drawableName', '')
        try:
            if not re.fullmatch(r'[a-z][a-z0-9_]*', name) or name in names: raise ValueError('invalid or duplicate drawableName')
            names.add(name)
            if entry.get('contentMode') != 'visualOnly': raise ValueError('only audited visualOnly assets may be processed')
            original = (source / (name + '.png')).resolve(strict=True)
            if original.parent != source: raise ValueError('input escaped source directory')
            final = destination / (name + '.webp')
            if final.is_symlink(): raise ValueError('refusing symlink destination')
            original_image = png_rgba(original)
            with tempfile.TemporaryDirectory(prefix='asset-', dir=source) as work:
                work = Path(work)
                compressed, webp, decoded = work/'compressed.png', work/'final.webp', work/'decoded.png'
                run(['crisppng', 'compress', str(original), '--output', str(compressed), '--preset', 'ui', '--json'] + compression_options)
                # CrispPNG may choose to keep the source when savings are insufficient.
                if not compressed.is_file(): raise ValueError('CrispPNG returned without an output PNG')
                compressed_image = png_rgba(compressed)
                if original_image[:2] != compressed_image[:2]: raise ValueError('compression changed dimensions')
                run(['cwebp', '-lossless', '-exact', '-metadata', 'icc', str(compressed), '-o', str(webp)])
                run(['dwebp', str(webp), '-o', str(decoded)])
                if png_rgba(decoded) != compressed_image: raise ValueError('WebP decoded RGBA does not match compressed PNG')
                for existing in destination.glob(name + '.*'):
                    if existing != final: raise ValueError(f'resource name collision: {existing.name}; resolve the task-owned PNG/XML explicitly')
                digest = hashlib.sha256(webp.read_bytes()).hexdigest()
                if final.exists() and hashlib.sha256(final.read_bytes()).hexdigest() != digest:
                    raise ValueError('existing WebP differs; refusing to overwrite an unowned asset')
                if not final.exists():
                    fd, staging = tempfile.mkstemp(prefix='.'+name, dir=destination)
                    os.close(fd)
                    try:
                        shutil.copyfile(webp, staging)
                        os.replace(staging, final)
                    finally:
                        if os.path.exists(staging): os.unlink(staging)
                report['assets'].append({'nodeId': entry.get('nodeId'), 'path': str(final), 'width': compressed_image[0],
                    'height': compressed_image[1], 'sourceBytes': original.stat().st_size, 'webpBytes': final.stat().st_size,
                    'compressionChangedPixels': original_image != compressed_image, 'webpLosslessVerified': True, 'sha256': digest})
        except (ValueError, OSError, RuntimeError, subprocess.TimeoutExpired, KeyError, zlib.error) as error:
            report['failedAssets'].append({'drawableName': name, 'error': str(error)})
    if report['failedAssets']: report['status'] = 'PARTIAL'
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--input-dir', required=True, help='Audited PNGs in the task evidence cache, including locally derived backgrounds')
    parser.add_argument('--out-dir', required=True)
    parser.add_argument('--compression-mode', choices=['local', 'production'], default='local')
    parser.add_argument('--phase0', help='Optional approved production configuration; otherwise use explicitly labelled local compression')
    parser.add_argument('--report', required=True)
    args = parser.parse_args()
    try: report = process(args)
    except Exception as error: report = {'schemaVersion': 1, 'status': 'BLOCKED', 'assets': [], 'failedAssets': [str(error)]}
    target = Path(args.report)
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix('.tmp')
    temporary.write_text(json.dumps(report, ensure_ascii=False, indent=2))
    temporary.replace(target)
    print(json.dumps(report, ensure_ascii=False))
    return 0 if report['status'] == 'SUCCESS' else 1

if __name__ == '__main__': sys.exit(main())
