import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { spawn } from "node:child_process";
import { fileURLToPath } from "node:url";
import { DATA_DIR, uploadPending } from "./uploader.mjs";

const CONFIG_FILE = path.join(DATA_DIR, "config.json");
const CATALOG_FILE = path.join(DATA_DIR, "catalog.json");
const QUEUE_FILE = path.join(DATA_DIR, "queue.jsonl");
const STATE_FILE = path.join(DATA_DIR, "state.json");
const HISTORY_FILE = path.join(DATA_DIR, "history.jsonl");
const SEEN_DIR = path.join(DATA_DIR, "seen");
const SESSIONS_DIR = path.join(DATA_DIR, "sessions");
const MAX_INPUT_BYTES = 1024 * 1024;
const MAX_SCAN_CHARS = 64 * 1024;
const MAX_QUEUE_BYTES = 5 * 1024 * 1024;
const MAX_HISTORY_ENTRIES = 100;
const SUPPORTED_HOSTS = new Set(["claude", "codex", "grok", "agy"]);

function readJson(file, fallback = {}) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}

function writeJsonAtomic(file, value) {
  const temp = `${file}.${process.pid}.tmp`;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(temp, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  fs.renameSync(temp, file);
}

function updateState(patch) {
  const state = readJson(STATE_FILE, {});
  writeJsonAtomic(STATE_FILE, { ...state, ...patch });
}

function hash(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

function canonicalHost(requestedHost) {
  if (!requestedHost && (process.env.GROK_HOOK_EVENT || process.env.GROK_SESSION_ID)) return "grok";
  return requestedHost || "unknown";
}

function firstString(...values) {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return value.trim();
    if (typeof value === "number") return String(value);
  }
  return "";
}

function readStdin() {
  return new Promise((resolve) => {
    let input = "";
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      resolve(input);
    };
    process.stdin.setEncoding("utf8");
    process.stdin.on("data", (chunk) => {
      if (input.length < MAX_INPUT_BYTES) input += chunk;
      if (input.length >= MAX_INPUT_BYTES) finish();
    });
    process.stdin.on("end", finish);
    process.stdin.on("error", finish);
    setTimeout(finish, 900).unref();
    process.stdin.resume();
  });
}

function parsePayload(input) {
  if (!input.trim()) return {};
  try {
    return JSON.parse(input.replace(/^\uFEFF/, ""));
  } catch {
    return {};
  }
}

function sessionId(payload) {
  return firstString(
    payload.session_id,
    payload.sessionId,
    payload.conversationId,
    payload.conversation_id,
    process.env.GROK_SESSION_ID,
    payload.transcript_path,
    payload.transcriptPath,
  );
}

function turnId(payload) {
  return firstString(
    payload.promptId,
    payload.prompt_id,
    payload.turn_id,
    payload.turnId,
    payload.stepIdx,
    payload.toolUseId,
    payload.tool_use_id,
    payload.tool_call_id,
    payload.toolCallId,
  );
}

function toolName(payload) {
  return firstString(
    payload.tool_name,
    payload.toolName,
    payload.toolCall?.name,
    payload.name,
  ).toLowerCase();
}

function toolInput(payload) {
  return payload.tool_input ?? payload.toolInput ?? payload.toolCall?.args ?? payload.input ?? {};
}

function collectStrings(value, output = [], depth = 0) {
  if (output.join("").length >= MAX_SCAN_CHARS || depth > 6) return output;
  if (typeof value === "string") {
    output.push(value.slice(0, MAX_SCAN_CHARS));
  } else if (Array.isArray(value)) {
    value.slice(0, 100).forEach((item) => collectStrings(item, output, depth + 1));
  } else if (value && typeof value === "object") {
    Object.values(value).slice(0, 100).forEach((item) => collectStrings(item, output, depth + 1));
  }
  return output;
}

function normalizeSkillName(value) {
  return String(value || "")
    .trim()
    .replace(/^@/, "")
    .replace(/^playbook-android[/:]/, "")
    .replace(/[^a-zA-Z0-9_-].*$/, "");
}

function detectSkills(payload, catalogSkills) {
  const known = new Set(catalogSkills);
  const name = toolName(payload);
  const input = toolInput(payload);
  const matches = new Map();
  const skillTool = ["skill", "use_skill", "useskill"].includes(name);
  const readTool = ["read", "read_file", "readfile", "read_text_file", "view_file"].some((item) =>
    name === item || name.endsWith(`__${item}`) || name.endsWith(`.${item}`));
  const commandTool = ["bash", "exec", "exec_command", "run_terminal_command", "shell", "run_command"].some((item) =>
    name === item || name.endsWith(`__${item}`) || name.endsWith(`.${item}`));

  if (!skillTool && !readTool && !commandTool) return [];

  const strings = collectStrings(input);

  if (skillTool) {
    const candidates = [
      input?.skill,
      input?.skill_name,
      input?.skillName,
      input?.name,
      ...strings,
    ];
    for (const candidate of candidates) {
      const skill = normalizeSkillName(candidate);
      if (known.has(skill)) matches.set(skill, "skill_tool");
    }
  }

  if (!readTool && !commandTool) {
    return [...matches.entries()].map(([skillId, source]) => ({ skillId, source }));
  }

  const combined = strings.join("\n").slice(0, MAX_SCAN_CHARS);
  // Skills may be exposed directly or through one or more namespaces/aliases,
  // for example `skills/android-ui/SKILL.md`,
  // `skills/playbook-android/android-ui/SKILL.md`, or
  // `skills/r1/playbook-android/android-ui/SKILL.md`. Capture the directory
  // immediately before SKILL.md/scripts, then validate it against catalog.
  const skillFilePattern = /(?:^|[\\/])skills(?:[\\/][a-zA-Z0-9_.-]+)*[\\/]([a-zA-Z0-9_-]+)[\\/]SKILL\.md(?:$|[\s"'`,;\]}])/g;
  const scriptPattern = /(?:^|[\\/])skills(?:[\\/][a-zA-Z0-9_.-]+)*[\\/]([a-zA-Z0-9_-]+)[\\/]scripts[\\/]/g;
  // Codex exposes nested file reads through functions.exec, so exact SKILL.md
  // paths are accepted from read tools and command envelopes, never prompts/output.
  if (readTool || commandTool) {
    for (const match of combined.matchAll(skillFilePattern)) {
      if (known.has(match[1])) matches.set(match[1], matches.get(match[1]) || "skill_file_read");
    }
  }
  if (commandTool) {
    for (const match of combined.matchAll(scriptPattern)) {
      if (known.has(match[1]) && !matches.has(match[1])) matches.set(match[1], "script_exec");
    }
  }
  return [...matches.entries()].map(([skillId, source]) => ({ skillId, source }));
}

function reserveEventUid(dedupeKey) {
  fs.mkdirSync(SEEN_DIR, { recursive: true });
  const marker = path.join(SEEN_DIR, hash(dedupeKey));
  const eventUid = crypto.randomUUID();
  try {
    const fd = fs.openSync(marker, "wx");
    fs.writeFileSync(fd, eventUid, "utf8");
    fs.closeSync(fd);
    return eventUid;
  } catch {
    return "";
  }
}

function randomSessionKey(config, host, rawSession) {
  fs.mkdirSync(SESSIONS_DIR, { recursive: true });
  const marker = path.join(SESSIONS_DIR, hash(`${config.clientId}|${host}|${rawSession}`));
  const newKey = crypto.randomUUID();
  try {
    fs.writeFileSync(marker, newKey, { encoding: "utf8", flag: "wx" });
    return newKey;
  } catch {
    try {
      const existing = fs.readFileSync(marker, "utf8").trim();
      return existing || newKey;
    } catch {
      return newKey;
    }
  }
}

function trimQueueIfNeeded() {
  try {
    if (!fs.existsSync(QUEUE_FILE) || fs.statSync(QUEUE_FILE).size <= MAX_QUEUE_BYTES) return;
    const lines = fs.readFileSync(QUEUE_FILE, "utf8").split("\n").filter(Boolean);
    const kept = [];
    let bytes = 0;
    for (let index = lines.length - 1; index >= 0; index -= 1) {
      const size = Buffer.byteLength(lines[index]) + 1;
      if (bytes + size > Math.floor(MAX_QUEUE_BYTES * 0.8)) break;
      kept.push(lines[index]);
      bytes += size;
    }
    const dropped = lines.length - kept.length;
    fs.writeFileSync(QUEUE_FILE, `${kept.reverse().join("\n")}\n`, "utf8");
    const state = readJson(STATE_FILE, {});
    updateState({ droppedCount: Number(state.droppedCount || 0) + dropped });
  } catch {
    updateState({ lastError: "queue_trim_failed" });
  }
}

function enqueue(event) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const historyWritten = appendHistory(event);
  fs.appendFileSync(QUEUE_FILE, `${JSON.stringify(event)}\n`, "utf8");
  trimQueueIfNeeded();
  updateState({
    lastObservedAt: Date.now(),
    lastError: historyWritten ? "" : "history_write_failed",
  });
  return true;
}

function appendHistory(event) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const lines = fs.existsSync(HISTORY_FILE)
      ? fs.readFileSync(HISTORY_FILE, "utf8").split("\n").filter(Boolean)
      : [];
    lines.push(JSON.stringify(event));
    const kept = lines.slice(-MAX_HISTORY_ENTRIES);
    const temp = `${HISTORY_FILE}.${process.pid}.tmp`;
    fs.writeFileSync(temp, `${kept.join("\n")}\n`, "utf8");
    fs.renameSync(temp, HISTORY_FILE);
    return true;
  } catch {
    return false;
  }
}

function spawnUploader() {
  const uploader = fileURLToPath(new URL("./uploader.mjs", import.meta.url));
  try {
    const child = spawn(process.execPath, [uploader], {
      detached: true,
      stdio: "ignore",
      env: process.env,
    });
    child.unref();
  } catch {
    updateState({ lastError: "uploader_start_failed" });
  }
}

function baseEvent(config, catalog, host, action, sessionKey) {
  return {
    event_id: "playbook_usage",
    action,
    event_time: Date.now(),
    host,
    host_version: config.hostVersions?.[host] || "",
    telemetry_version: config.telemetryVersion || "1.0.0",
    playbook_revision: catalog.revision || "",
    client_id: config.clientId,
    session_key: sessionKey,
  };
}

async function main() {
  const requestedHost = process.argv[2] || "unknown";
  const eventType = process.argv[3] || "pre-tool-use";
  const synchronous = process.argv.includes("--sync");
  const config = readJson(CONFIG_FILE, {});
  const catalog = readJson(CATALOG_FILE, { skills: [] });
  if (!config.enabled || !config.clientId) return;
  let enqueued = false;
  let diagnosticEventUid = "";

  if (eventType === "diagnostic") {
    const event = baseEvent(config, catalog, "weagent", "diagnostic", crypto.randomUUID());
    event.event_uid = crypto.randomUUID();
    diagnosticEventUid = event.event_uid;
    event.activation_source = "telemetry_tab";
    enqueued = enqueue(event);
  } else {
    // Only collect explicitly supported host adapters.
    if (!SUPPORTED_HOSTS.has(requestedHost)) return;
    const payload = parsePayload(await readStdin());
    const host = canonicalHost(requestedHost);
    if (host === "agy" && (eventType !== "post-tool-use" || payload.error)) return;
    const rawSession = sessionId(payload);
    if (!rawSession) return;
    const sessionKey = randomSessionKey(config, host, rawSession);

    if (eventType === "pre-tool-use" || (host === "agy" && eventType === "post-tool-use")) {
      const rawTurn = turnId(payload) || firstString(payload.toolUseId, payload.tool_use_id);
      if (!rawTurn) return;
      for (const match of detectSkills(payload, catalog.skills || [])) {
        const eventUid = reserveEventUid(
          `${config.clientId}|${host}|${rawSession}|${rawTurn}|${match.skillId}`,
        );
        if (!eventUid) continue;
        const event = baseEvent(config, catalog, host, "skill_activate", sessionKey);
        event.resource_id = `playbook-android/${match.skillId}`;
        event.activation_source = match.source;
        event.event_uid = eventUid;
        enqueued = enqueue(event) || enqueued;
      }
    }
  }

  if (synchronous) {
    const result = await uploadPending(diagnosticEventUid);
    if (result.status !== "uploaded") process.exitCode = 1;
  } else if (enqueued) {
    // Every enqueue needs a wakeup. A time throttle without a delayed worker
    // strands events arriving just after the previous worker exits. The uploader
    // lock already coalesces concurrent workers and drains in-flight appends.
    spawnUploader();
  }
}

try {
  await main();
} catch {
  try { updateState({ lastError: "collector_error" }); } catch { /* ignore */ }
  process.exitCode = process.argv.includes("--sync") ? 1 : 0;
} finally {
  // AGY PostToolUse expects an empty JSON response and makes no permission decision.
  if (process.argv[2] === "agy") process.stdout.write("{}\n");
}
