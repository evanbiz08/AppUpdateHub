import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import http from "node:http";
import https from "node:https";
import { fileURLToPath } from "node:url";

export const DATA_DIR = process.env.FIGMARESTORE_TELEMETRY_HOME
  || process.env.WEAGENT_TELEMETRY_HOME
  || path.join(os.homedir(), ".figmarestore", "playbook-telemetry");

const QUEUE_FILE = path.join(DATA_DIR, "queue.jsonl");
const STATE_FILE = path.join(DATA_DIR, "state.json");
const CONFIG_FILE = path.join(DATA_DIR, "config.json");
const LOCK_FILE = path.join(DATA_DIR, "uploader.lock");
const MAX_BATCH_SIZE = 100;
const STALE_LOCK_MS = 60_000;

function readJson(file, fallback = {}) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}

function writeJsonAtomic(file, value) {
  const temp = `${file}.${process.pid}.tmp`;
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(temp, `${JSON.stringify(value, null, 2)}\n`, "utf8");
  fs.renameSync(temp, file);
}

function queueCount() {
  try {
    return fs.readFileSync(QUEUE_FILE, "utf8").split("\n").filter(Boolean).length;
  } catch {
    return 0;
  }
}

function updateState(patch) {
  const state = readJson(STATE_FILE, {});
  writeJsonAtomic(STATE_FILE, {
    ...state,
    ...patch,
    queueCount: queueCount(),
  });
}

function toGatewayEvent(event) {
  return {
    platform: "desktop",
    app: "weagent",
    app_channel: event.host || "unknown",
    host: event.host || "unknown",
    uid: 0,
    device_id: event.client_id || "",
    region: "",
    country_code: "",
    language_code: "",
    version_code: 1,
    version_name: event.telemetry_version || "1.0.0",
    network_type: "unknown",
    network_operator: "",
    network_available: 1,
    device_name: "",
    os_version: "",
    api_level: 0,
    background: 0,
    organic_install: 1,
    gender: 0,
    action: event.action,
    event_id: "playbook_usage",
    event_time: event.event_time,
    source: event.activation_source || "",
    // PlayBook Telemetry owns these extension slots. All queryable dimensions
    // use physical ClickHouse columns; this event does not write event_value.
    str_key_1: event.resource_id || "",
    str_key_2: event.session_key || "",
    str_key_3: event.host_version || "",
    str_key_4: event.playbook_revision || "",
    str_key_5: event.event_uid || "",
  };
}

function postJson(urlString, events, timeoutMs) {
  return new Promise((resolve, reject) => {
    const url = new URL(urlString);
    const transport = url.protocol === "http:" ? http : https;
    const body = JSON.stringify(events.map(toGatewayEvent));
    const request = transport.request({
      protocol: url.protocol,
      hostname: url.hostname,
      port: url.port || undefined,
      path: `${url.pathname}${url.search}`,
      method: "POST",
      headers: {
        "content-type": "application/json; charset=utf-8",
        "content-length": Buffer.byteLength(body),
        // The existing gateway routes to a ClickHouse database by this header.
        // V1 is intentionally isolated in the yoki test database.
        app: "yoki",
      },
      timeout: timeoutMs,
    }, (response) => {
      response.resume();
      response.on("end", () => {
        if (response.statusCode >= 200 && response.statusCode < 300) {
          resolve();
        } else {
          reject(new Error(`http_${response.statusCode || 0}`));
        }
      });
    });
    request.on("timeout", () => request.destroy(new Error("network_timeout")));
    request.on("error", reject);
    request.end(body);
  });
}

function appendLines(lines) {
  if (lines.length === 0) return;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.appendFileSync(QUEUE_FILE, `${lines.join("\n")}\n`, "utf8");
}

function isSupportedEvent(line) {
  try {
    const event = JSON.parse(line);
    if (!["claude", "codex", "grok", "agy", "weagent"].includes(event.host)) return false;
    return event.action === "skill_activate" || event.action === "diagnostic";
  } catch {
    return false;
  }
}

function safeErrorCode(error) {
  const message = String(error?.message || "upload_failed");
  if (/^http_\d+$/.test(message)) return message;
  if (message === "network_timeout") return message;
  if (message === "diagnostic_event_missing") return message;
  return "network_error";
}

function acquireLock() {
  try {
    return fs.openSync(LOCK_FILE, "wx");
  } catch {
    try {
      if (Date.now() - fs.statSync(LOCK_FILE).mtimeMs <= STALE_LOCK_MS) return undefined;
      fs.rmSync(LOCK_FILE, { force: true });
      return fs.openSync(LOCK_FILE, "wx");
    } catch {
      return undefined;
    }
  }
}

export async function uploadPending(requiredEventUid = "") {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const lock = acquireLock();
  if (lock === undefined) return { status: "busy" };

  const inflight = path.join(DATA_DIR, `queue.${process.pid}.jsonl`);
  let retryLines = [];
  try {
    const config = readJson(CONFIG_FILE, {});
    if (!config.uploadUrl) {
      updateState({ lastError: "upload_url_missing" });
      return { status: "failed", error: "upload_url_missing" };
    }
    if (!fs.existsSync(QUEUE_FILE) || fs.statSync(QUEUE_FILE).size === 0) {
      updateState({ lastError: "" });
      return { status: "empty" };
    }

    fs.renameSync(QUEUE_FILE, inflight);
    // Drop events from older runtimes. Usage analysis only needs Skill
    // activations; diagnostics remain available for the manual chain check.
    let lines = fs.readFileSync(inflight, "utf8")
      .split("\n")
      .filter(Boolean)
      .filter(isSupportedEvent);
    if (requiredEventUid) {
      const requiredIndex = lines.findIndex((line) => {
        try { return JSON.parse(line).event_uid === requiredEventUid; } catch { return false; }
      });
      if (requiredIndex < 0) throw new Error("diagnostic_event_missing");
      const [requiredLine] = lines.splice(requiredIndex, 1);
      lines = [requiredLine, ...lines];
    }
    const batchLines = lines.slice(0, MAX_BATCH_SIZE);
    retryLines = batchLines;
    appendLines(lines.slice(MAX_BATCH_SIZE));

    const events = batchLines.map((line) => JSON.parse(line));
    await postJson(config.uploadUrl, events, config.uploadTimeoutMs || 2500);
    fs.rmSync(inflight, { force: true });
    updateState({
      lastUploadAt: Date.now(),
      lastError: "",
    });
    return { status: "uploaded", count: events.length };
  } catch (error) {
    try {
      if (fs.existsSync(inflight)) {
        appendLines(
          retryLines.length > 0
            ? retryLines
            : fs.readFileSync(inflight, "utf8").split("\n").filter(Boolean),
        );
        fs.rmSync(inflight, { force: true });
      }
    } catch {
      // Keep the original failure category; the next reconciliation reports backlog.
    }
    const errorCode = safeErrorCode(error);
    updateState({ lastError: errorCode });
    return { status: "failed", error: errorCode };
  } finally {
    try { if (lock !== undefined) fs.closeSync(lock); } catch { /* ignore */ }
    try { fs.rmSync(LOCK_FILE, { force: true }); } catch { /* ignore */ }
  }
}

if (path.resolve(process.argv[1] || "") === fileURLToPath(import.meta.url)) {
  // A hook can append a new event while the current batch is in flight. Drain
  // a few follow-up batches so those events are not stranded until the next
  // hook invocation (or lost to the uploader-start throttle).
  let result = await uploadPending();
  for (let attempt = 0; attempt < 10 && result.status === "uploaded"; attempt += 1) {
    await new Promise((resolve) => setTimeout(resolve, 250));
    if (queueCount() === 0) break;
    result = await uploadPending();
  }
  process.exitCode = result.status === "failed" ? 1 : 0;
}
