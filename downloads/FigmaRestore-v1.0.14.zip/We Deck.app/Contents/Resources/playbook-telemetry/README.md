# PlayBook Skill 统计

支持 Claude Code、Codex、Grok、AGY。仅记录 catalog 中的 Skill 激活事件，继续使用现有队列、去重、历史记录与 ClickHouse 上报字段。

新增宿主的配置位置：

| Agent | 配置 | 采集入口 |
| --- | --- | --- |
| AGY | `~/.gemini/config/hooks.json` 中的 `weagent-playbook-telemetry` | `PostToolUse` |

在「PlayBook 统计」中点击「修复配置」安装或更新配置。已有运行时升级到 1.0.14 时会为检测到的新增 CLI 安装适配器，保留已有启用状态、上报地址和 client ID。升级后才安装的 CLI 需要再次修复配置。



接口依据：

- [AGY Hooks](https://antigravity.google/docs/hooks)

AGY 在工具执行成功后采集，失败调用不计入；统计 Hook 不参与权限决策。

1.0.14 移除 Pi / OMP 适配。升级时仅将本应用生成的旧统计扩展重命名为不可加载的备份；保留用户配置与其他扩展。旧宿主的队列事件不再上报。
