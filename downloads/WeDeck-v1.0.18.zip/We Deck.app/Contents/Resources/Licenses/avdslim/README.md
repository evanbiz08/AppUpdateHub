# Bundled avdslim

- Upstream: https://github.com/kdbhalala/avdslim
- Version: v1.0.16, darwin_arm64 (Apple Silicon only)
- Source: official GitHub Release v1.0.16, avdslim_v1.0.16_darwin_arm64.tar.gz; archive verified against the release checksums.txt, executable unmodified before local bundle signing.
- SHA-256 before bundle signing: b503e996f5b73c4dfac695f0a5331627a034c2d213de29d193cf3f4cb956dd6f
- Archive SHA-256: 26219bc445394b76e7fc866552f3180463bd1963f3dbe886055826fdeba4f480
- License: MIT, see LICENSE; installer includes it in the app's Resources/Licenses.

The app calls `on`/`off` with an explicit emulator serial and SDK PATH. It does not install a shim or invoke aggressive mode. Camera/media/accessibility packages are kept, all tweak groups are skipped. Existing independently disabled packages are added to --keep. Aggressive-only packages are also kept to protect against an external defaults file enabling that mode.

An upgrade must review upstream flags, state-file schema, package lists and license before replacing this pinned binary. Intel distribution requires a matching amd64 binary and host architecture selection; it is not currently provided.
