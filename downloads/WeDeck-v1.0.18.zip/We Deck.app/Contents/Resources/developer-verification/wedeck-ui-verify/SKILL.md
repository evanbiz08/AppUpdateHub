---
name: wedeck-ui-verify
description: "面向客户端开发者，在需求完成后操作已连接 Android 设备验证界面、复现问题、巡检发版展示或回放固定流程。通过 We Deck 的执行器观察真实 UI、断言结果、保存截图与 YAML；内置 Lama、Yoki、Waka、Fungo、InChat、GameParty Pro、Hayi、HiChat、Ludo、Ludo KSA、WeParty 共 11 个 Android App，也支持用户自行配置。"
---

# 自动化UI

使用当前开发会话已有的需求、改动与验收点，补充必要的运行前置。不要把开发者任务改写成独立测试工程，也不要生成单元测试或擅自构建、安装、清空 App。

## 选择入口

We Deck 调度的会话已绑定 App、设备和运行目录，直接使用 `wedeck_ui` MCP。

在开发者自己的 Agent 中，从本 SKILL.md 所在目录定位 `scripts/wedeck-ui`，先执行 `apps`、`devices` 获取实际配置和明确的设备 serial。这个脚本调用已安装 We Deck 中的独立执行器，不要求桌面窗口保持打开。

```sh
"$SKILL_DIR/scripts/wedeck-ui" apps
"$SKILL_DIR/scripts/wedeck-ui" devices
"$SKILL_DIR/scripts/wedeck-ui" prepare --app APP_ID --device SERIAL --mode feature --intent '本次需求与验收点'
```

prepare 返回 `run` 目录；之后每个命令显式传递该目录：

```sh
"$SKILL_DIR/scripts/wedeck-ui" start --run RUN_DIR
"$SKILL_DIR/scripts/wedeck-ui" launch --run RUN_DIR
"$SKILL_DIR/scripts/wedeck-ui" look --run RUN_DIR --screenshot
"$SKILL_DIR/scripts/wedeck-ui" look --run RUN_DIR
```

其他命令：`do --commands 'YAML'`、`look --all`、`save`、`clear --starting-state '实际起点'`、`log`、`stop`、`finish --report FILE.json`，均需要 `--run RUN_DIR`。支持 MCP 的客户端也可以注册本脚本的 `mcp` 命令；它提供同一套执行和归档能力。

## 内置 App 速查

下表来自各仓库 `app/build.gradle` 与 `gradle.properties`。App 的 id 即 `prepare --app` 的取值，源码在 `~/wenext-limited/<仓库>`。包名以设备上 `pm path` 实际结果为准；渠道包（huawei、lite）包名带后缀，需在 App 配置里改包名后再运行。

| id | 仓库 | 包名 | 深链 scheme://host | 其他渠道 |
| --- | --- | --- | --- | --- |
| lama | lama-android | com.wenext.lama | wenext://lama | huawei、lite（lite 包名 com.wenext.voice） |
| yoki | yoki-android | com.partyjoy.yoki | partyki://yoki | huawei、lite（.lite 后缀） |
| waka | wyak-android | com.wenext.wayak | wenext://wayak | lite（com.wenext.wyaklite） |
| fungo | fungo-android | com.gamparty.fungo | gamparty://fungo | huawei（.huawei 后缀） |
| inchat | gameparty-android | com.wenext.inchat | partychat://inchat | 无 |
| gameparty-pro | gameparty-pro-android | com.partyjoy.gameparty.pro.hw | gmparty://gameparty | 无 |
| hayi | hayi-android | com.gamparty.hayi | haparty://hayi | huawei（.huawei 后缀） |
| hichat | hichat-android | com.partyjoy.hichat | partyhi://hichat | 无 |
| ludo | ludo-android | com.courage.ludo | courage://ludo | huawei（.huawei 后缀） |
| ludoksa | ludoksa-android | com.courage.ludo.ksa.hw | courageksa://ludo | 无 |
| weparty | weparty-android | com.partyjoy.weparty | partyjoy://weparty | 无 |

共同点，可直接按此推断，不必逐个 App 再确认：

- 11 个项目都基于 wenext-android-frame，页面由 `@RouterUri(path=[...])` 注册，深链形如 `scheme://host/path?参数`；先在仓库里 `rg "RouterUri"` 找到真实 path 和参数，再用 `openLink` 或 `adb shell am start -a android.intent.action.VIEW -d '...'` 直达。
- 主界面都是 `com.adealink.weparty.MainActivity`；启动用本工具的 `launch`/`launch_app`，不要自己写 `launchApp`。
- 全部带 `/debug` 页面（`DebugActivity`），`?testAccount=正整数` 可切换测试账号；仅 Debug 构建可用，生产环境不得使用。需要登录态时优先参考 `android-test-account` skill，没有明确测试账号就报告 blocked。
- Debug 构建带 LeakCanary，会多出一个启动图标，本工具的 `launch` 已排除。
- 视图为 XML + ViewBinding：控件 id 通常是 `binding` 对应的 `@+id/...`，查 id 先看对应 Activity/Fragment 的布局文件，再用 `look` 核对设备上的实际 resource id。
- 未装对应渠道包时，preflight 会直接提示包名不匹配，按提示修改 App 配置，不要反复重试。

## YAML 写法速查

执行器是 Speedrun 0.4.4，语法对齐 Maestro。已确认可用的命令：`tapOn`、`longPressOn`、`inputText`、`eraseText`、`pressKey`、`hideKeyboard`、`scrollUntilVisible`、`assertVisible`、`assertNotVisible`、`assertTrue`、`extendedWaitUntil`、`waitForAnimationToEnd`、`openLink`、`takeScreenshot`、`assertScreenshot`、`copyTextFrom`、`pasteText`、`runFlow`、`repeat`、`evalScript`、`runScript`、`stopApp`、`clearState`、`setLocation`。`assertWithAI` 等 AI 命令不支持，不要写。

- 回放文件的头部写 `appId: 包名`；初始启动由执行器负责，流程里不要再写 `launchApp`。
- 优先用 `id:` 选择器（`tapOn: {id: "..."}`），其次是文本；文本在多语言下会变，需要固定语言时在前置里说明。`do` 里可用 `@7` 引用，保存时会自动转成选择器。
- 每次点击后用 `assertVisible`/`assertNotVisible` 断言业务结果，不要只靠 `waitForAnimationToEnd`。
- 列表、弹层先用 `scrollUntilVisible` 或 `extendedWaitUntil` 等待出现，再点击；上游对 Compose 滚动和弹层点击仍有已知问题，失败两次后用截图记录并报告，不要继续换坐标。
- 一个流程只覆盖一个起点，起点前置写进 `clear --starting-state`，不要把登录、弹窗清理混入固定步骤。

## 状态与结论怎么判断

- 单个检查项只有 passed、failed、blocked。整体按 failed > blocked > passed 汇总：任何一项 failed 即未通过；有 blocked 或缺少 evidence 即未验证；全部 passed 且都有具体 evidence 才算通过。
- 该做而没覆盖的验收点写 blocked，说明缺什么、做到哪一步，不能省略。
- 回放模式的结论来自 JUnit 报告（`report.xml`）：断言失败为 failed，被跳过为 blocked，执行器非零退出会追加一条「流程执行」失败项。
- 运行记录状态：执行中、通过、未通过、未验证、已取消。进程提前结束或没有提交 `finish` 结论的运行显示为未验证，不会当作通过。

## 执行时的关键判断

- `start`/`session_start` 只连接设备，不保证目标 App 在前台。CLI 使用 `launch`，MCP 使用 `launch_app`，随后观察并核对包名/目标页面。该入口会处理 Debug 构建额外的 LeakCanary 图标，避免 Speedrun 0.4.4 将系统选择器误判为主入口。不要使用 clearState 作为默认启动参数。
- 按真实 UI 的 resource id、文本或当前 @引用操作。@引用不能凭空猜测；操作后重新观察。看不到节点时使用完整树或截图，不用坐标猜测跨 App 通用流程。
- 页面内功能的验证可以在查明真实 Router/DeepLink 后直达；入口路径本身属于验收点时必须走真实路径。仅 Activity resumed、点击成功或控件存在不能替代业务结果断言。
- 已有登录态优先复用。未登录且用户提供了明确的测试环境账号时，可使用项目已有 Debug 登录能力；先确认实际项目契约。生产环境不使用测试账号绕过登录。前置缺失用 blocked，不能编造账号、房间号或登录成功。
- 只执行用户目标内的业务行为，不擅自发送消息、赠礼、购买、支付、删除或修改资料。相同失败最多诊断重试两次，避免重复提交业务数据。
- 项目源码用于只读发现控件和入口，遵守该项目 AGENTS.md。不要因为验收失败就顺带改源码、切环境、执行 Git 或 Gradle；这需要另一个明确的开发任务。

## 根据目标调整验证

- 需求验收：逐条验证改动后的可见行为，覆盖相关状态和边界；需求没覆盖或前置不满足的项明确标出。
- 问题复现：记录触发条件、所有失败尝试、实际状态和截图。不要将“未复现”写成问题已修复。
- 发版巡检：按指定固定操作逐项验证，保存稳定的 YAML，复用公共流程时保留 App 专属选择器和环境差异。
- 视觉检查：获取截图，按参考图或验收标准检查布局、文案、遮挡、截断、语言及状态。没有参考图时不声称像素一致。动态动画需要观察多个时刻，静态截图不能证明完整动画或音视频正常。
- 固定流程回放：prepare 时选择 replay，然后执行 `replay --run RUN_DIR --flow FILE_OR_DIRECTORY`。执行器先启动所选 App，再回放 YAML；初始启动不用写进 YAML。无需模型全程操作；相对资源由原流程目录解析。执行前核对 YAML 的 appId、环境、账号前置和数据修改行为与当前目标一致。导入的 YAML 若自己包含 launchApp，仍受上游多启动入口解析限制，需要按实际目标调整。

## 保存结果

执行中按需 `look --screenshot`；截图路径在返回文本中，可由 Agent 的图片工具查看。完整尝试保存在 `operations.jsonl`。`save`/`save_flow` 仅保存成功操作为 `flow.yaml`，不包含失败尝试，不能单独作为问题复现报告。

达到稳定的验证起点后，用 CLI `clear --starting-state` 或 MCP `session_clear` 开始录制可回放部分。起点和前置写入 flow-context.json，流程开头增加起点断言。偶然弹出的系统窗口、手动登录等 setup 不要混进固定操作；完整尝试日志不受清理录制影响。

结束前保存有效流程，然后提交每个验收点的结论。CLI 将下面的结构写成运行目录内 JSON，再调用 `finish --run RUN_DIR --report FILE.json`；MCP 使用 `finish` 工具。

```json
{
  "summary": "实际观察到的结果与未验证范围",
  "checks": [
    {"title": "用户要求的验收点", "status": "passed", "evidence": "具体观察、断言、截图路径或业务状态"},
    {"title": "缺少前置的验收点", "status": "blocked", "evidence": "缺少什么，已经验证到哪一步"}
  ]
}
```

status 只使用 passed、failed、blocked。所有要求都应有结论；只有点击成功、进程退出码为 0 或部分步骤完成时不能整体通过。UI 证据不替代未检查的后端或双账号业务结果。

finish 会停止设备会话、恢复动画设置并释放占用。异常中断时执行 stop，保留已产生的证据。每次 prepare/session_start 创建新的本地运行记录，桌面「自动化UI → 运行记录」自动显示，可单独删除已结束记录。

要复用或分享，在运行记录的「流程」菜单中保存到流程库，再导出或分享 YAML。也可以在流程库导入别人发来的 YAML，选择对应 App 和设备后运行；导入不会自动执行，也不会新增运行记录。包含相对路径子流程、脚本或图片时，导入和分享整个流程目录。流程库与运行记录分别保存，删除运行记录不会删除已入库的流程。不把账号密钥或无关个人信息复制到报告或共享 YAML。
